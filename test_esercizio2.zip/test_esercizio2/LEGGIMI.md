ESERCIZIO 2 — cercaFile stringa dir num

Prova consigliata:
  ./cercaFile.sh errore "$(pwd)/sorgente" 2

RISULTATO ATTESO:
  La directory con più file .txt validi è:
  <percorso-assoluto>/sorgente/gamma

Conteggi (per singola directory, NON includendo le sottodirectory):
  sorgente        1
  sorgente/alfa   2
  sorgente/alfa/sotto 1
  sorgente/beta   1
  sorgente/beta/sotto 1
  sorgente/gamma  4   <-- vincitrice
  sorgente/gamma/sotto 1
  sorgente/vuota  0

Ogni file valido deve essere leggibile, terminare in .txt e contenere
la parola "errore" in almeno 2 RIGHE distinte.
Le .log e .java non contano. Un file che contiene la parola su una sola
riga non conta.

Nota: la consegna richiede di stampare il NOME della directory vincitrice.
Non serve spostare o cancellare file.
